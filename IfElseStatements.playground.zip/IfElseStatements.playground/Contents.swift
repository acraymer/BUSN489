let a = false
let b = false
let c = true

if a {
    print("a is true")
}
else if !a || !b {print("a or b are false")}
else {
    print("a is false")
}

//&& and operator
//|| or operator

for r in 1...8{
    print("g")
}
            
        
