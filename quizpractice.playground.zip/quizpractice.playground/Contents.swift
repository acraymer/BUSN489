print("Hello, world!")

var myVariable = 42
myVariable = 50

let myConstant = 42

print(myVariable)
print(myConstant)

//let myConstant = 30 this will cause an error
// myConstant = 30 this will also cause an error
print(myConstant)

let implicitInteger = 70
let implicitDouble = 70.0
let explicitDouble: Double = 70

let explicitFloat: Float = 4

let label = "The width is"
let width = 94
let widthLabel = label + String(width) //excluding the conversion to string results in error
print(widthLabel)

let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples."
let fruitSummary = "I have \(apples + oranges) pieces of fruit."

var fruits = ["strawberries", "limes", "tangerines"]
fruits[1] = "grapes"
print(fruits)

var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",
]
//dictionaries are organized alphabetically

occupations["Jayne"] = "Public Relations"
print(occupations)

fruits.append("blueberries")
print(fruits)
//empty array: []
//empty dictionary: [:]

let emptyArray: [String] = []
let emptyDictionary: [String: Float] = [:]
//let emptyArray = [] this would cause an error. empty collection literals require explicit types.

let individualScores = [75, 43, 103, 87, 12]
var teamScore = 0
for score in individualScores {
    if score > 50 {
        teamScore += 3
    } else {
        teamScore += 1
    }
}

print(Int(teamScore))

